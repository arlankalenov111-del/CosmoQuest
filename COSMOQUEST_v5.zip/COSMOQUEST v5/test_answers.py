"""Test accepted RU / EN / KK variants and question selection."""
from pathlib import Path
from playwright.sync_api import sync_playwright
r=Path(__file__).parent
h=(r/'index.html').read_text();css=(r/'styles.css').read_text();source=(r/'app.js').read_text()
source=source.replace('function findAnswer(q,answer){', 'window.__cqAnswers={get questions(){return RECALL},check(q,a){return !!findAnswer(q,a)},daily(){return dailyRecallQuestions().map(q=>q.q.en)}};function findAnswer(q,answer){')
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page();page.set_content(h);page.add_style_tag(content=css);page.add_script_tag(content=source)
 stats=page.evaluate('''() => {let count=0,failed=[];for(const q of __cqAnswers.questions){for(const variants of q.a){for(const v of variants){count++;if(!__cqAnswers.check(q,v))failed.push(q.q.en+' : '+v);}}}const planet=__cqAnswers.questions[0];return {count,failed,categories:__cqAnswers.questions.length,groups:__cqAnswers.questions.reduce((n,q)=>n+q.a.length,0),unknown:__cqAnswers.check(planet,'not a planet'),pluto:__cqAnswers.check(planet,'Pluto'),mars:__cqAnswers.check(planet,'Марс'),earth:__cqAnswers.check(planet,'Жер'),daily:__cqAnswers.daily()};}''')
 assert stats['count']>=700,stats
 assert stats['failed']==[],stats['failed'][:10]
 assert stats['unknown']==False and stats['pluto']==False
 assert stats['mars']==True and stats['earth']==True
 assert len(stats['daily'])==len(set(stats['daily']))==7
 print('RECALL',stats['categories'],'categories,',stats['groups'],'answer groups,',stats['count'],'accepted variants')
 print('ALL_ANSWER_VARIANTS_VALID',len(stats['failed'])==0,'UNKNOWN_REJECTED',not stats['unknown'],'PLUTO_NOT_CLASSIFIED_PLANET',not stats['pluto'])
 b.close()
