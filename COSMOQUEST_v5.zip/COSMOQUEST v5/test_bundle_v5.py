"""Check the exact standalone HTML and legacy save migration with Chromium."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import sys,json,datetime
R=Path(__file__).parent
SRC=R/'app.js'
HTML=(R/'index.html').read_text(encoding='utf8')
CSS=(R/'styles.css').read_text(encoding='utf8')
JS=SRC.read_text(encoding='utf8')
KEY='cosmoquest-mission-survival-v2'
standalone=HTML.replace('<link rel="stylesheet" href="styles.css">','<style>\n'+CSS+'\n</style>').replace('<script src="app.js" defer></script>','').replace('</body>','<script>\n'+JS.replace('</script','<\\/script')+'\n</script>\n</body>')
assert 'src="app.js"' not in standalone and 'href="styles.css"' not in standalone
(R.parent/'COSMOQUEST_v5.html').write_text(standalone,encoding='utf-8')
(R/'COSMOQUEST_single.html').write_text(standalone,encoding='utf-8')
print('Wrote HTML bundle',len(standalone),'bytes')
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 # The browser environment forbids file:// and local http navigation. set_content loads the exact bundled HTML instead.
 page=b.new_page(viewport={'width':1200,'height':800})
 page.on('pageerror',lambda e:print('JS ERROR',e))
 page.set_content(standalone)
 assert page.locator('[data-action="skip-onboard"]').count()==1
 page.locator('[data-action="skip-onboard"]').click()
 page.locator('[data-nav="academy"]').first.click()
 page.locator('[data-action="open-lesson"][data-id="w6"]').click()
 assert page.locator('.lesson-diagram .diagram-node').count()==3
 page.locator('[data-action="lesson-intro-next"]').click()
 assert page.locator('[data-action="lesson-choice"]').count()==3
 print('PASS standalone HTML startup + Academy actions')
 # Legacy v3 (v4 exported as version 3) with no spaced-repetition fields.
 page2=b.new_page(viewport={'width':1024,'height':768})
 page2.set_content(HTML)
 page2.add_style_tag(content=CSS)
 legacy={'version':3,'onboardDone':True,'nick':'Old Explorer','monster':'bloop','owned':[],'coins':345,'xp':400,'lessons':['w0','w1'],'moduleFinals':[],'words':{'w0':{'correct':2},'w1':{'correct':1}},'settings':{'language':'ru','difficulty':'normal'},'daily':{'date':''}}
 page2.evaluate('''({key,value})=>Object.defineProperty(window,'localStorage',{configurable:true,value:{_v:{[key]:JSON.stringify(value)},getItem(k){return this._v[k]??null},setItem(k,v){this._v[k]=v},removeItem(k){delete this._v[k]}}})''',{'key':KEY,'value':legacy})
 page2.add_script_tag(content=JS)
 saved=page2.evaluate('JSON.parse(localStorage.getItem("'+KEY+'"))')
 assert page2.locator('#main').count()==1 and page2.locator('[data-action="skip-onboard"]').count()==0
 assert saved['coins']==345 and saved['xp']==400 and len(saved['lessons'])==2
 page2.locator('[data-nav="academy"]').first.click()
 page2.locator('[data-action="academy-tab"][data-tab="review"]').click()
 assert page2.locator('[data-action="review-open"]').count()==2
 print('PASS legacy save keeps coins, XP, lessons; both words due for review')
 # Test due-date progression: repeated successful completion advances the interval from 1 -> 3 days.
 page2.locator('[data-action="review-open"][data-id="w0"]').click()
 page2.locator('[data-action="lesson-intro-next"]').click()
 page2.locator('[data-action="lesson-choice"][data-value="w0"]').click()
 page2.locator('[data-action="lesson-go-matching"]').click()
 for id in page2.locator('[data-lesson-match]').evaluate_all('(els)=>els.map(e=>e.dataset.lessonMatch)'):
  page2.locator(f'[data-lesson-match="{id}"]').select_option(id)
 page2.locator('[data-action="lesson-check-matching"]').click()
 page2.locator('[data-action="lesson-go-gap"]').click()
 page2.locator('#lesson-gap-input').fill('Планета')
 page2.locator('[data-form="lesson-gap"] button[type="submit"]').click()
 page2.locator('[data-action="lesson-go-review"]').click()
 page2.locator('[data-action="lesson-complete"]').click()
 s=page2.evaluate('JSON.parse(localStorage.getItem("'+KEY+'"))')
 assert s['coins']>=345 and s['stats']['lessonCompleted']==0
 assert s['words']['w0']['intervalDays']==1
 page2.locator('[data-action="lesson-back"]').first.click()
 page2.locator('[data-action="open-lesson"][data-id="w0"]').click()
 page2.locator('[data-action="lesson-intro-next"]').click()
 page2.locator('[data-action="lesson-choice"][data-value="w0"]').click()
 page2.locator('[data-action="lesson-go-matching"]').click()
 for id in page2.locator('[data-lesson-match]').evaluate_all('(els)=>els.map(e=>e.dataset.lessonMatch)'):
  page2.locator(f'[data-lesson-match="{id}"]').select_option(id)
 page2.locator('[data-action="lesson-check-matching"]').click()
 page2.locator('[data-action="lesson-go-gap"]').click()
 page2.locator('#lesson-gap-input').fill('Планета')
 page2.locator('[data-form="lesson-gap"] button[type="submit"]').click()
 page2.locator('[data-action="lesson-go-review"]').click()
 page2.locator('[data-action="lesson-complete"]').click()
 newer=page2.evaluate('JSON.parse(localStorage.getItem("'+KEY+'"))')
 assert newer['words']['w0']['intervalDays']==3
 assert newer['stats']['lessonCompleted']==0
 print('PASS spaced repetition advances 1 to 3 days; old completed lesson not rewarded twice')
 b.close()
print('BUNDLE & SAVE CHECKS PASSED')
